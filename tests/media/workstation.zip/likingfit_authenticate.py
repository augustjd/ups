import hashlib
import os
import random
import json
import string
import time
import sys
import enum

import requests


def random_string(length, characters=string.ascii_lowercase):
    return ''.join(random.choice(characters) for _ in range(length))


def timestamp():
    return int(time.time())


LIKINGFIT_API_KEY = "JKk7c8gaP9MMFyXD"
LIKINGFIT_API_BASE = "http://smartspot.likingfit.com/v1"

class LikingFitApi:
    def __init__(self,
                 api_base=LIKINGFIT_API_BASE,
                 api_key=LIKINGFIT_API_KEY,
                 device_id=os.getenv("SMARTSPOT_WORKSTATION_ID")):
        self.api_key = api_key
        self.device_id = device_id
        self.api_base = api_base

    def _sign_request(self, obj):
        request_timestamp = timestamp()
        request_id_length = 16
        request_id = random_string(request_id_length)

        def sign(timestamp, request_id):
            encoding = 'utf-8'
            m = hashlib.sha1(self.api_key.encode(encoding))
            m.update(f"{self.api_key}{timestamp}{request_id}".encode(encoding))
            return m.hexdigest()

        obj["request_id"] = request_id
        obj["timestamp"] = request_timestamp
        obj["signature"] = sign(request_timestamp, request_id)
        return obj

    def response_successful(self, response):
        if type(response) == requests.models.Response:
            if response.status_code != 200:
                return False

            response = response.json()

        try:
            return response.get('err_code') == 0
        except Exception:
            return False

    def authenticate(self, bracelet_id, brush_time=timestamp(),
                     timeout=1.0,
                     **options):
        url = f"{self.api_base}/user/checkin"

        request = {
            "device_id": self.device_id,
            "brush_time": brush_time,
            "bracelet_id": bracelet_id
        }

        return requests.post(url, data=self._sign_request(request),
                             timeout=timeout, **options)

    def notify_workout_set_complete(self, bracelet_id, workout_id,
                                    workout_set_id,
                                    timeout=1.0,
                                    **options):
        url = f"{self.api_base}/notice/record"

        request = {
            "device_id": self.device_id,
            "bracelet_id": bracelet_id,
            "workout_id": workout_id,
            "set_id": workout_set_id,
        }

        return requests.post(url, data=self._sign_request(request),
                             timeout=timeout, **options)


class ReturnCodes(enum.IntEnum):
    ValidWristband = 0
    InvalidWristband = 1
    NetworkingError = 2


if __name__ == "__main__":
    if os.getenv("SMARTSPOT_DEVELOPMENT"):
        print("Skipping authentication, SMARTSPOT_DEVELOPMENT is set.")
        sys.exit(ReturnCodes.ValidWristband)

    api = LikingFitApi()

    bracelet_id = int(sys.argv[1])
    try:
        response = api.authenticate(bracelet_id)
        print(response.json())
    except Exception:
        sys.exit(ReturnCodes.NetworkingError)

    if api.response_successful(response):
        if response.json()['data']['check_result']:
            sys.exit(ReturnCodes.ValidWristband)
        else:
            sys.exit(ReturnCodes.InvalidWristband)
    else:
        sys.exit(ReturnCodes.NetworkingError)
